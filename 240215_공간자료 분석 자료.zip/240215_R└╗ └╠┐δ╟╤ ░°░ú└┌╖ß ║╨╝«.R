#### 서울 지도 ####

library(rgdal)
seoul_dong <- readOGR("D:/Data/2402_통계특강/240215_GIS 특강 자료/seoul_dong.shp")
proj4string(seoul_dong) <- CRS("+init=epsg:4326")

seoul_gu <- readOGR("D:/Data/2402_통계특강/240215_GIS 특강 자료/seoul_gu.shp")
proj4string(seoul_gu) <- CRS("+init=epsg:4326")

seoul_all <- readOGR("D:/Data/2402_통계특강/240215_GIS 특강 자료/seoul_all.shp")
proj4string(seoul_all) <- CRS("+init=epsg:4326")

plot(seoul_all, border="green", lwd=4)
plot(seoul_gu, border="red", lwd=2, add=TRUE)
plot(seoul_dong, border="blue", lwd=1, add=TRUE)

#### 지도 위에 지명 추가 ####

library(rgeos)
seoul_center <- gCentroid(seoul_dong, byid=TRUE)
dong_name <- as.data.frame(seoul_dong[c("EMD_KOR_NM")])
seoul_center <- as.data.frame(seoul_center)
seoul_center <- cbind(seoul_center, dong_name)
coordinates(seoul_center) <- ~x+y
proj4string(seoul_center) <- CRS("+init=epsg:4326")

plot(seoul_dong)
plot(seoul_center, col="red", lwd=2, add=TRUE)

plot(seoul_dong)
text(seoul_center, seoul_center$EMD_KOR_NM, col="grey55", cex=0.5)

#### Shapefile에 데이터 추가하기 ####

# CSV File #
pop1 <- read.csv("D:/Data/2402_통계특강/240215_GIS 특강 자료/서울_법정동_성별 주민등록 인구증감_20240131.csv", fileEncoding="EUC-KR")

# 서울 인구 데이터 추가 #
seoul_dong <- merge(seoul_dong, pop1, by.x="EMD_CD", by.y="법정동코드", all.x=TRUE)
seoul_dong$전체.당월인구수 <- ifelse(is.na(seoul_dong$전체.당월인구수) == TRUE, 0, seoul_dong$전체.당월인구수)

library(latticeExtra)
spplot(seoul_dong, "전체.당월인구수", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu, lwd=1.5, col="blue"))

#### 지도에서 특정 지역만 추출 ####

# 특정 구만 따로 분석 #
seoul_gu1 <- seoul_gu[(seoul_gu$SIG_KOR_NM == "성북구"),]
plot(seoul_gu1)

# 특정 구에 해당하는 동을 선택 #
library(raster)
seoul_dong1 <- intersect(seoul_gu1, seoul_dong)
seoul_dong1 <- seoul_dong1[(seoul_dong1$시군구명 == "성북구"),]

plot(seoul_dong1)
plot(seoul_gu1, border="red", lwd=2, add=TRUE)

spplot(seoul_dong1, "전체.당월인구수", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu1, lwd=1.5, col="blue"))

#### point Shapefile ####

seoul_store <- read.csv("D:/Data/2402_통계특강/240215_GIS 특강 자료/소상공인시장진흥공단_상가(상권)정보_서울_202312.csv", fileEncoding="UTF-8")
coordinates(seoul_store) <- ~경도+위도
proj4string(seoul_store) <- CRS("+init=epsg:4326")
seoul_store <- seoul_store[(seoul_store$상권업종소분류명 == "편의점"),]

plot(seoul_store)
plot(seoul_all, border="red", lwd=2, add=TRUE)

seoul_store1 <- intersect(seoul_store, seoul_gu1)

plot(seoul_gu1, border="red", lwd=2)
plot(seoul_store1, add=TRUE)
plot(seoul_dong1, border="blue", lwd=2, add=TRUE)

library(ptools)
seoul_dong_store <- count_xy(seoul_dong1, seoul_store1)
seoul_dong1 <- cbind(seoul_dong1, seoul_dong_store)
ren <- ncol(seoul_dong1)
names(seoul_dong1)[ren] <- "num_store"
seoul_dong1$num_store <- as.numeric(seoul_dong1$num_store)

spplot(seoul_dong1, "num_store", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu1, lwd=1.5, col="green"))

seoul_dong1$num_store1 <- ifelse(seoul_dong1$num_store > 40, 40, seoul_dong1$num_store)

spplot(seoul_dong1, "num_store1", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu1, lwd=1.5, col="green"))

#### 인접공간 파악 ####
library(spdep)
nei1 <- poly2nb(seoul_dong1, snap=10, queen=TRUE)
seoul_nb1 <- nb2listw(nei1, zero.policy=TRUE)

library(rgeos)
dong_center <- gCentroid(seoul_dong1, byid=TRUE)

plot(seoul_dong1)
plot(seoul_nb1, dong_center, add=TRUE)


#### 격자(grid) shapefile ####

# Grid SHP File #
seoul_grid <- readOGR("D:/Data/2402_통계특강/240215_GIS 특강 자료/seoul_500.shp")
proj4string(seoul_grid) <- CRS("+init=epsg:5178")
# 좌표계 변환 #
seoul_grid <- spTransform(seoul_grid, CRS("+init=epsg:4326"))

plot(seoul_grid)
plot(seoul_gu, border="blue", lwd=2, add=TRUE)

spplot(seoul_grid, "val", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu, lwd=1.5, col="blue"))

#### 선(line) shapefile ####

road <- readOGR("D:/Data/2402_통계특강/240215_GIS 특강 자료/sb_road.shp", use_iconv=TRUE, encoding="UTF-8")
proj4string(road) <- CRS("+init=epsg:4326")

spplot(road, "MAX_SPD", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(seoul_gu1, lwd=1.5, col="blue"))
