#### 청주시 지도 ####

library(rgdal)
cj_dong <- readOGR("E:/Data/240125_GIS 특강/cj_dong.shp")
proj4string(cj_dong) <- CRS("+init=epsg:4326")

cj_gu <- readOGR("E:/Data/240125_GIS 특강/cj_gu.shp")
proj4string(cj_gu) <- CRS("+init=epsg:4326")

cj_all <- readOGR("E:/Data/240125_GIS 특강/cj_all.shp")
proj4string(cj_all) <- CRS("+init=epsg:4326")

plot(cj_all, border="green", lwd=3)
plot(cj_gu, border="red", lwd=2, add=TRUE)
plot(cj_dong, border="blue", lwd=1, add=TRUE)

#### 지도 위에 지명 추가 ####

library(rgeos)
cj_center <- gCentroid(cj_dong, byid=TRUE)
dong_name <- as.data.frame(cj_dong[c("ADM_DR_NM")])
cj_center <- as.data.frame(cj_center)
cj_center <- cbind(cj_center, dong_name)
coordinates(cj_center) <- ~x+y
proj4string(cj_center) <- CRS("+init=epsg:4326")

plot(cj_dong)
plot(cj_center, col="red", lwd=2, add=TRUE)

plot(cj_dong)
text(cj_center, cj_center$ADM_DR_NM, col="grey55", cex=0.5)

#### Shapefile에 데이터 추가하기 ####

# CSV File #
cj_pop <- read.csv("E:/Data/240125_GIS 특강/청주시 동별 인구.csv", fileEncoding="EUC-KR")
# Excel File #
library(readxl)
cj_pop1 <- read_excel("E:/Data/240125_GIS 특강/청주시 동별 인구.xlsx", col_names=TRUE, sheet=1)

# 청주시 인구 데이터 추가 #
cj_dong <- merge(cj_dong, cj_pop, by.x="ADM_DR_NM", by.y="nm")

library(latticeExtra)
spplot(cj_dong, "pop", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu, lwd=1.5, col="blue"))

#### 지도에서 특정 지역만 추출 ####

# 특정 구만 따로 분석 #
cj_gu1 <- cj_gu[(cj_gu$SIG_KOR_NM == "청주시 상당구" | cj_gu$SIG_KOR_NM == "청주시 청원구"),]
plot(cj_gu1)

# 특정 구에 해당하는 동을 선택 #
library(raster)
cj_dong1 <- intersect(cj_gu1, cj_dong)

plot(cj_dong1)
plot(cj_gu1, border="red", lwd=2, add=TRUE)

spplot(cj_dong1, "pop", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu1, lwd=1.5, col="blue"))

#### point Shapefile ####

cj_store <- read.csv("E:/Data/240125_GIS 특강/소상공인시장진흥공단_상가(상권)정보_충북_202309.csv", fileEncoding="UTF-8")
coordinates(cj_store) <- ~경도+위도
proj4string(cj_store) <- CRS("+init=epsg:4326")

plot(cj_store)
plot(cj_all, border="red", lwd=2, add=TRUE)

cj_store1 <- intersect(cj_all, cj_store)

plot(cj_store1)
plot(cj_all, border="red", lwd=2, add=TRUE)
plot(cj_dong, border="blue", lwd=2, add=TRUE)

library(ptools)
cj_dong_store <- count_xy(cj_dong, cj_store1)
cj_dong <- cbind(cj_dong, cj_dong_store)
names(cj_dong)[7] <- "num_store"

spplot(cj_dong, "num_store", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu, lwd=1.5, col="green")) +
  layer(sp.polygons(cj_all, lwd=2, col="blue"))

cj_dong$store_km2 <- cj_dong$num_store/cj_dong$km2

spplot(cj_dong, "store_km2", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu, lwd=1.5, col="green")) +
  layer(sp.polygons(cj_all, lwd=2, col="blue"))

cj_dong$store_km2a <- ifelse(cj_dong$store_km2 > 1000, 1000, cj_dong$store_km2)

spplot(cj_dong, "store_km2a", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu, lwd=1.5, col="green")) +
  layer(sp.polygons(cj_all, lwd=2, col="blue"))

#### 격자(grid) shapefile ####

# Grid SHP File #
cj_grid <- readOGR("E:/Data/240125_GIS 특강/충청북도 청주시_인구정보-총 인구 수(전체)/nlsp_020001001.shp")
proj4string(cj_grid) <- CRS("+init=epsg:5178")
# 좌표계 변환 #
cj_grid <- spTransform(cj_grid, CRS("+init=epsg:4326"))

plot(cj_grid)
plot(cj_gu, border="blue", lwd=2, add=TRUE)

spplot(cj_grid, "val", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_gu, lwd=1.5, col="blue"))

#### 선(line) shapefile ####

road <- readOGR("E:/Data/240125_GIS 특강/cj_road.shp", use_iconv=TRUE, encoding="UTF-8")
proj4string(road) <- CRS("+init=epsg:4326")

spplot(road, "MAX_SPD", col.regions=rev(heat.colors(50)), col="grey55") +
  layer(sp.polygons(cj_all, lwd=1.5, col="blue"))


